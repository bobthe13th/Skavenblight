package net.minecraft.client.gui.components;

import com.mojang.blaze3d.systems.RenderSystem;
import javax.annotation.Nullable;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.network.chat.CommonComponents;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class StateSwitchingButton extends AbstractWidget {
    @Nullable
    protected WidgetSprites sprites;
    protected boolean isStateTriggered;

    public StateSwitchingButton(int x, int y, int width, int height, boolean initialState) {
        super(x, y, width, height, CommonComponents.EMPTY);
        this.isStateTriggered = initialState;
    }

    public void initTextureValues(WidgetSprites sprites) {
        this.sprites = sprites;
    }

    public void setStateTriggered(boolean triggered) {
        this.isStateTriggered = triggered;
    }

    public boolean isStateTriggered() {
        return this.isStateTriggered;
    }

    @Override
    public void updateWidgetNarration(NarrationElementOutput p_259073_) {
        this.defaultButtonNarrationText(p_259073_);
    }

    @Override
    public void renderWidget(GuiGraphics p_283051_, int p_283010_, int p_281379_, float p_283453_) {
        if (this.sprites != null) {
            RenderSystem.disableDepthTest();
            p_283051_.blitSprite(this.sprites.get(this.isStateTriggered, this.isHoveredOrFocused()), this.getX(), this.getY(), this.width, this.height);
            RenderSystem.enableDepthTest();
        }
    }
}
